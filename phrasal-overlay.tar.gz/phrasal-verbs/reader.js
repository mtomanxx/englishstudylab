(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const node = (tag, content, cls) => {const item=document.createElement(tag);if(content)item.textContent=content;if(cls)item.className=cls;return item;};
  $('grammar-check').addEventListener('submit', e => {
    e.preventDefault();
    const answer = new FormData(e.currentTarget).get('answer');
    $('check-feedback').textContent=!answer?'Choose one of the two sentences first.':answer==='b'?'Correct. In “turn it down,” the pronoun sits between the verb and the particle.':'Try again. With this separable verb, put the object pronoun before “down.”';
  });
  const rows=window.ESL_PHRASAL_VERBS||[];
  const types={intransitive:'No object',separable:'Separable',inseparable:'Inseparable','three-word':'Three-word',variable:'More than one pattern','fixed-frame':'Fixed object order'};
  const icons={
    time:['M12 7v5l3 2','M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z'],
    person:['M16 20v-3c0-3-8-3-8 0v3','M15 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z'],
    group:['M9 18c0-4-7-4-7 0v2m20 0v-2c0-4-7-4-7 0','M8 9a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm13 0a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z','M12 12v7m-2-3h4'],
    book:['M3 5c4-1 7 0 9 2 2-2 5-3 9-2v13c-4-1-7 0-9 2-2-2-5-3-9-2Z','M12 7v13M6 9h3m6 0h3'],
    chart:['M4 4v16h16','m7 15 4-4 4 2 4-6','M16 7h3v3'],
    food:['M3 12h18M6 12a6 6 0 0 1 12 0M12 6V4M6 16h12m-10 3h8'],
    money:['M2 7h20v11H2Z','M15 12.5a3 2.5 0 1 1-6 0 3 2.5 0 0 1 6 0Z','M5 12h1m12 0h1'],
    sound:['M4 9H1v6h3l5 4V5Z','M13 8a5 5 0 0 1 0 8m3-11a9 9 0 0 1 0 14'],
    rain:['M7 13h11a4 4 0 1 0-1.2-7.8A5.2 5.2 0 0 0 7 7a3 3 0 1 0 0 6Zm1 3-1 2m5-2-1 3m5-3-1 2'],
    move:['M4 11h15m-6-6 6 6-6 6'],
    talk:['M4 4h16v11H9l-5 4V4Zm4 5h8m-8 3h5'],
    send:['M3 5h18v14H3Z','m3 6 8.9 7L21 6'],
    alert:['M10.6 3.7c.7-1.2 2.1-1.2 2.8 0l8.1 14.5c.6 1.1-.1 2-1.4 2H3.9c-1.3 0-2-1-1.4-2Z','M12 8v4m0 4h.01'],
    screen:['M3 3h18v14H3Zm4 18h10m-5-4v4'],
    room:['M2 20h20M5 20V9l7-5 7 5v11m-10 0v-6h6v6'],
    bag:['M5 8h14l2 13H3Zm4 2V6a3 3 0 1 1 6 0v4'],
    work:['M3 8h18v12H3Zm5 0V4h8v4M3 12l9 3 9-3'],
    door:['M4 20h16M6 20V4h10v16m-3-8h.01'],
    doc:['M5 3h10l4 4v14H5V3Zm10 0v5h4m-10 4h6m-6 4h6'],
    car:['m3 13 3-6h12l3 6v5H3Zm3 5v2m12-2v2m-12-5h1m10 0h1'],
    search:['M15 10a6 6 0 1 1-12 0 6 6 0 0 1 12 0Zm-1 4 6 6'],
    tools:['m4 19 9-9m0 0-1-5 3-2 2 2-2 2 2 2 2-2 2 2-2 3-5-1m-9 9 2 2'],
    tick:['M3 4h18v16H3Z','m7 12 3 3 7-7'],
    spark:['M12 2v5m0 10v5M2 12h5m10 0h5M5 5l3 3m8 8 3 3M19 5l-3 3m-8 8-3 3'],
    dot:['M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z','M3 12h3m12 0h3']
  };
  const rules=[
    [/rain|weather|cloud|storm/,'rain'],[/meal|food|dinner|lunch|coffee|drink|cook|bake|pizza/,'food'],[/music|volume|sound|noise|loud|radio/,'sound'],
    [/car\b|truck|bike|traffic|bus\b|vehicle/,'car'],[/computer|file|tech|online|screen|device/,'screen'],[/letter|email|message|reply|mail\b/,'send'],
    [/book|chapter|read|stud(y|ent)|language/,'book'],[/business|meeting|office|job|work|task|project|career/,'work'],[/pack|bag|box|delivery|parcel|shop/,'bag'],
    [/room|house|home|office|building|store/,'room'],[/knock|gate|door|entrance|leave|arrive/,'door'],
    [/time|late|date|wait|sudden|deadline|schedule|hours|minutes|day\b|month/,'time'],
    [/money|pay|cost|budget|cash|rent|deposit|discount/,'money'],[/rise|grow|sales|level|price|score|progress|reduce|increase/,'chart'],
    [/fix|build|repair|break|tool|clean/,'tools'],[/find|look|search|check|discover|spot/,'search'],
    [/talk|say|ask|tell|speak|suggest|explain|call|chat/,'talk'],[/team|people|crowd|friends|group|staff|family/,'group'],
    [/person|child|face|friend|neighbor|driver|agent|worker|guest/,'person'],[/plan|paper|note|list|contract|report|ticket|record/,'doc'],
    [/no\b|not\b|problem|fail|wrong|missing|empty|danger|lost|stuck|broken|closed/,'alert'],[/done|success|ready|clear|finish|complete|solved|agree|accept|approve/,'tick'],
    [/move|go\b|run|walk|jump|push|pull|turn|lift|drop|carry|throw/,'move']
  ];
  const svgNS='http://www.w3.org/2000/svg';
  function pictogram(label,step){
    const key=rules.find(([match])=>match.test(label.toLowerCase()))?.[1]||['dot','spark','tick'][step];
    const graphic=document.createElementNS(svgNS,'svg');
    graphic.setAttribute('viewBox','0 0 24 24');
    graphic.setAttribute('aria-hidden','true');
    graphic.setAttribute('focusable','false');
    for(const d of icons[key]){const p=document.createElementNS(svgNS,'path');p.setAttribute('d',d);graphic.append(p);}
    return graphic;
  }
  const voice = new Audio();
  voice.preload='none';
  let speaker=null,token=0, speech=null;
  function finish(message){
    speaker?.setAttribute('aria-pressed','false');
    speaker=null;
    $('stop').disabled=true;
    $('audio-status').textContent=message||'';
  }
  function stop(message){
    token++;
    voice.pause();
    if(speech){window.speechSynthesis?.cancel();speech=null;}
    finish(message);
  }
  function fallback(id,label,text){
    if(id!==token)return;
    const engine=window.speechSynthesis;
    const us=engine?.getVoices?.().find(v=>v.localService&&/^en[-_]US$/i.test(v.lang));
    if(!us||!window.SpeechSynthesisUtterance){finish('US audio cannot play on this device. You can still read the verb and example.');return;}
    speech=new SpeechSynthesisUtterance(text);
    speech.voice=us;speech.lang='en-US';speech.rate=.9;
    speech.onend=()=>{if(id===token){speech=null;finish('Finished '+label+'.');}};
    speech.onerror=()=>{if(id===token){speech=null;finish('US audio could not play.');}};
    $('audio-status').textContent='Playing '+label+' with your device’s US English voice.';
    engine.speak(speech);
  }
  function play(btn,row,kind){
    if(btn===speaker){stop('Audio stopped.');return;}
    stop();
    const id=token,label=kind==='term'?row.verb:'example for '+row.verb;
    speaker=btn;btn.setAttribute('aria-pressed','true');$('stop').disabled=false;
    $('audio-status').textContent='Playing '+label+' in US English.';
    voice.src=new URL('audio/'+row.id+'-'+kind+'.mp3',document.baseURI).href;
    voice.onended=()=>{if(id===token)finish('Finished '+label+'.');};
    try{Promise.resolve(voice.play()).catch(()=>fallback(id,label,kind==='term'?'to '+row.verb:row.example));}
    catch(e){fallback(id,label,kind==='term'?'to '+row.verb:row.example);}
  }
  $('stop').onclick=()=>stop('Audio stopped.');
  window.addEventListener('pagehide',()=>stop());
  const describe={before:'Before',motion:'Action',after:'After'};
  function renderCard(row){
    const article=node('article',null,'card');article.id=row.id;article.dataset.level=row.level;
    const heading=node('h3',row.verb);heading.id=row.id+'-heading';
    article.setAttribute('aria-labelledby',heading.id);
    const top=node('header',null,'card-head');
    const link=node('a','Link to entry','perma');link.href='#'+row.id;link.setAttribute('aria-label','Link to '+row.verb+': '+row.meaning);
    top.append(heading,link);
    const badges=node('ul',null,'badges');badges.append(node('li',row.level),node('li',types[row.grammar]));
    const story=node('figure',null,'story'), caption=node('figcaption','Visual cue · '+row.verb);
    const timeline=node('ol');
    for(const [step,key] of ['before','motion','after'].entries()){
      const word=row.visual[key], box=node('li');
      const label=node('strong',word);const prefix=node('span',describe[key]+': ','sr-only');
      label.prepend(prefix);box.append(pictogram(word,step),label);timeline.append(box);
    }
    story.append(caption,timeline);
    const structure=node('p',null,'grammar-line');
    structure.append(node('strong','Grammar pattern: '),document.createTextNode(row.pattern));
    const ex=node('blockquote');ex.append(node('span','Example','example-label'),node('div',row.example));
    const audio=node('div',null,'card-audio');
    for(const [kind,text] of [['term','▶ Hear the verb'],['example','▶ Hear the example']]){
      const button=node('button',text);button.type='button';
      button.setAttribute('aria-label',kind==='term'?'Hear '+row.verb+' in US English':'Hear example for '+row.verb+' in US English');
      button.setAttribute('aria-pressed','false');button.onclick=()=>play(button,row,kind);audio.append(button);
    }
    article.append(top,badges,node('p',row.meaning,'meaning'),story,structure,ex,audio);
    if(row.tip)article.append(node('p',row.tip,'tip'));
    return article;
  }
  if(rows.length<1){$('results').textContent='The index did not load. Reload this page to retry.';return;}
  const family=row=>row.verb.toLowerCase().split(' ')[0];
  const format=text=>String(text||'').normalize('NFKD').toLowerCase().replace(/[’‘]/g,"'").replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();
  for(const term of [...new Set(rows.map(family))].sort()){$('family').add(new Option(term,term));}
  const keyed=rows.map(row=>({row,text:format([row.verb,row.meaning,row.example,row.pattern,row.tip].join(' '))}));
  const idmap=new Map(rows.map((r,i)=>[r.id,i]));
  const size=20;
  let curr=1, max=1;
  const filt=$('filters'), box=$('cards'), pages=$('page');
  function setQuery(){
    const desired=new URLSearchParams(location.search);
    for(const [id,key] of [['query','q'],['family','family'],['level','level'],['pattern','grammar']]){$(id).value=desired.get(key)||'';}
    curr=parseInt(desired.get('page'),10)||1;
  }
  function updateUrl(clearHash=false){
    const u=new URL(location.href);
    for(const [id,key] of [['query','q'],['family','family'],['level','level'],['pattern','grammar']]){
      const v=$(id).value.trim();
      if(v)u.searchParams.set(key,v);else u.searchParams.delete(key);
    }
    if(curr>1)u.searchParams.set('page',String(curr));else u.searchParams.delete('page');
    if(clearHash && idmap.has(decodeHash()))u.hash='index';
    if(location.href!==u.href)try{history.replaceState(null,'',u);}catch(e){}
  }
  function render(focus=false,sync=true){
    if(speaker)stop('Audio stopped.');
    const query=format($('query').value).split(' ').filter(Boolean);
    const hits=keyed.filter(x=>(!$('family').value||family(x.row)===$('family').value)&&(!$('level').value||x.row.level===$('level').value)&&(!$('pattern').value||x.row.grammar===$('pattern').value)&&query.every(t=>x.text.includes(t)));
    max=Math.max(1,Math.ceil(hits.length/size));curr=Math.max(1,Math.min(curr,max));const from=(curr-1)*size;
    $('results').textContent=hits.length?`Showing ${from+1}–${Math.min(from+size,hits.length)} of ${hits.length} entries · Page ${curr} of ${max}`:'No entries match these filters.';
    const fragment=document.createDocumentFragment();
    for(const item of hits.slice(from,from+size))fragment.append(renderCard(item.row));
    if(!hits.length)fragment.append(node('p','Try a shorter search or reset the filters.','empty'));
    box.replaceChildren(fragment);
    pages.replaceChildren(...Array.from({length:max},(_,i)=>new Option(`${i+1} of ${max}`,String(i+1))));
    pages.value=String(curr);pages.disabled=max===1;
    $('prev').disabled=curr===1;$('next').disabled=curr>=max;
    if(sync)updateUrl(focus||!!document.activeElement.closest?.('#filters'));
    if(focus){$('results').focus({preventScroll:true});$('results').scrollIntoView({block:'start'});}
  }
  filt.addEventListener('submit',e=>{e.preventDefault();curr=1;render();});
  let typing;
  $('query').addEventListener('input',()=>{clearTimeout(typing);typing=setTimeout(()=>{curr=1;render();},120);});
  for(const id of ['family','level','pattern'])$(id).addEventListener('change',()=>{curr=1;render();});
  filt.addEventListener('reset',()=>setTimeout(()=>{curr=1;render();},0));
  $('prev').onclick=()=>{curr--;render(true);};$('next').onclick=()=>{curr++;render(true);};
  pages.onchange=()=>{curr=Number(pages.value);render(true);};
  function decodeHash(){try{return decodeURIComponent(location.hash.slice(1));}catch(e){return '';}}
  function followHash(){
    const id=decodeHash();
    if(!idmap.has(id))return false;
    const existing=document.getElementById(id);
    if(!existing){for(const field of ['query','family','level','pattern'])$(field).value='';curr=1+Math.floor(idmap.get(id)/size);render(false,false);}
    requestAnimationFrame(()=>document.getElementById(id)?.scrollIntoView({block:'start'}));
    return true;
  }
  window.addEventListener('hashchange',followHash);
  window.addEventListener('popstate',()=>{setQuery();if(!followHash())render(false,false);});
  setQuery();
  if(!followHash())render(false,false);
})();
