(() => {
  "use strict";
  const home = document.getElementById('root');
  if (!home) return;
  const mount = new URL('../phrasal-verbs/',document.currentScript.src);
  function a(label,hook,anchor=''){
    const el=document.createElement('a');
    el.href=mount.href+anchor;el.dataset.eslPhrasalLink=hook;el.textContent=label;
    return el;
  }
  function place(){
    const toc=home.querySelector('.esl-book-contents');
    if(toc&&!toc.querySelector('[data-esl-phrasal-link="contents"]')){
      const link=a('Phrasal verbs in action · 500 entries','contents');
      const num=document.createElement('small');num.textContent='07';link.prepend(num);toc.append(link);
    }
    const skills=home.querySelector('.ac-skills-section');
    if(skills&&!skills.querySelector('[data-esl-phrasal-link="skills"]')){
      const line=document.createElement('p');line.className='esl-phrasal-spot';
      line.append(a('Grammar companion: 500 phrasal verbs','skills','#grammar'));
      skills.append(line);
    }
    const lesson=home.querySelector('.ac-lesson-page');
    const crumb=lesson?.querySelector('.ac-lesson-breadcrumb > span');
    const title=lesson?.querySelector('header.ac-lesson-title');
    if(!title||crumb?.textContent?.trim()!=='Grammar'||title.querySelector('[data-esl-phrasal-link="grammar"]'))return;
    const panel=document.createElement('p');panel.className='esl-phrasal-spot';
    panel.append(a('Open the phrasal verb grammar guide','grammar','#grammar'));
    const tabs=title.querySelector('.ac-lesson-tabs');
    if(tabs)tabs.before(panel);else title.append(panel);
  }
  let queued=false;
  const schedule=()=>{
    if(queued)return;
    queued=true;
    requestAnimationFrame(()=>{queued=false;place();});
  };
  new MutationObserver(schedule).observe(home,{subtree:true,childList:true});
  schedule();
})();
